print('demo')
